//
//  MenuViewController.swift
//  PigRage3-12-18
//
//  Created by Emily on 3/13/18.
//  Copyright © 2018 Emily. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {

    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var optionsBtn: UIButton!
    @IBOutlet weak var creditsBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func drawMenu(){
        
    }

}
