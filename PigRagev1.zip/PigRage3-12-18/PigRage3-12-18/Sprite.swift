//
//  Sprite.swift
//  PigRage3-12-18
//
//  Created by Emily on 3/13/18.
//  Copyright © 2018 Emily. All rights reserved.
//

import Foundation
import SpriteKit

class Sprite{
//    var movingV: Direction  = .NEITHER
//    var moving: Direction = .RIGHT
//    var facing: Direction = .RIGHT
    var animColumns = 0
    var animRows = 0
    var animStartX = 0
    var animStartY = 0
    var x = 0
    var y = 0
    var width = 0
    var height = 0
//    var xdelay = 0
//    var ydelay = 0
//    var xcount = 0
//    var ycount = 0
//    var velx = 0.0
//    var vely = 0.0
//    var speed = 0.0
    var curframe = 0
    var totalFrames = 0
    var frameCount = 0
    var frameDelay = 0
    var animDir = 1
//    var faceAngle = 0
//    var moveAngle = 0
//    var damaged = false
//    var damagedR = false
//    var damagedL = false
//    var hit = false
//    var jump = false
//    var jumpDelay = 0
//    var jumpSpeed = 0
//    var gravity = 1

    var gameScene = GameScene()
    
//    func loadPlayer() ->SKSpriteNode{
//        
//        return player
//    }
// 
    
//    func drawframe(scrollX: Int) -> (fx: Int, fy: Int) {
//        var fx: Int = animStartX + (curframe % animColumns) * width
//        var fy: Int = animStartY + (curframe / animColumns) * height
//        var position = [fx:fy]
//        return (fx, fy)
//    }
//
    func updateAnimation(){
//        for i in frameCount{
//
//            if(num > frameDelay){
//                frameCount = 0
//                curframe += animDir
//
//                if(curframe < 0){
//                    curframe = totalFrames - 1
//                }
//                else if(curframe > totalFrames - 1){
//                    curframe = 0
//                }
//            }
//
//        }
        
    }
    
}
