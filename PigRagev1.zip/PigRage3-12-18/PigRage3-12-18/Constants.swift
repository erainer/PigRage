//
//  Constants.swift
//  PigRage3-12-18
//
//  Created by Emily on 3/13/18.
//  Copyright © 2018 Emily. All rights reserved.
//

import Foundation

public enum State {case TITLE; case PLAYING; case OPTIONS;  case CREDITS;  case QUIT; case PAUSE; case GAMEOVER; case WIN; case LOADING}
public enum Direction {case UP; case DOWN; case LEFT; case RIGHT; case NEITHER}

