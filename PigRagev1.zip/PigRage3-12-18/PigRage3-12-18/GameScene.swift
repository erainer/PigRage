//
//  GameScene.swift
//  PigRage3-12-18
//
//  Created by Emily on 3/12/18.
//  Copyright © 2018 Emily. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {

    //Pig Avatar Run
    var player = SKSpriteNode()
    var playerRunArr = [SKTexture]()
    let playerRun1 = "Pig_Avatar_01"
    let playerRun2 = "Pig_Avatar_02"
    let playerRun3 = "Pig_Avatar_03"
    let playerRun4 = "Pig_Avatar_04"
    let playerRun5 = "Pig_Avatar_05"
    let playerRun6 = "Pig_Avatar_06"
    let playerRun7 = "Pig_Avatar_07"
    
    //Pig Avatar Jump
    var jumping = SKSpriteNode()
    var playerJump = [SKTexture]()
    let playerJump1 = "Pig_Avatar_Jump1"
    let playerJump2 = "Pig_Avatar_Jump2"
    
    //Background
    var background = Background()
    var scroll = false
    let level1 = SKTexture(imageNamed: "Level1")
    let cloud = SKSpriteNode(imageNamed: "cloud")
    override func didMove(to view: SKView) {
        //Background
        self.backgroundColor = UIColor(red: 0.2941, green: 0.502, blue: 0.949, alpha: 1.0)
        self.addChild(background)
        createPlayer()
        self.addChild(cloud)
        //Double Tap
//        let tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
//        tap.numberOfTapsRequired = 2
//        view.addGestureRecognizer(tap)
    }
    
    func createPlayer(){
        playerRunArr.append(SKTexture(imageNamed: playerRun1))
        playerRunArr.append(SKTexture(imageNamed: playerRun2))
        playerRunArr.append(SKTexture(imageNamed: playerRun3))
        playerRunArr.append(SKTexture(imageNamed: playerRun4))
        playerRunArr.append(SKTexture(imageNamed: playerRun5))
        playerRunArr.append(SKTexture(imageNamed: playerRun6))
        playerRunArr.append(SKTexture(imageNamed: playerRun7))
        
        //Player Properties
        player.name = "player"
        player.position = CGPoint(x: (scene!.size.width / 3) - 75, y: 275)
        player.zPosition = 1
        player.size = CGSize( width: 212, height: 320)
        self.addChild(player)
        
        playerJump.append(SKTexture(imageNamed: playerJump1))
        playerJump.append(SKTexture(imageNamed: playerJump2))
        
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        player.run(SKAction.repeatForever(SKAction.animate(with: playerRunArr, timePerFrame: 0.2)))
        scroll = true
    }

    override func touchesEnded(_ touches: Set<UITouch>,
                      with event: UIEvent?){
        player.removeAllActions()
        scroll = false
    }
    
//    @objc func doubleTapped() {
//        player.run(SKAction.repeatForever(SKAction.animate(with: playerJump, timePerFrame: 0.2)))
//    }
    
    
    override func update(_ currentTime: TimeInterval) {
        
        let initPosCloud = CGPoint(x: scene!.size.width, y: 800)
        //Moves the grounds left
        cloud.position = CGPoint(x: cloud.position.x - 5, y: 800)
        //Resets the position of the ground once it is off the screen
        if(cloud.position.x < -510){
            cloud.position.x = initPosCloud.x + 510
        }
        if(scroll == true){
            background.moveGround()
        }
    }
}
