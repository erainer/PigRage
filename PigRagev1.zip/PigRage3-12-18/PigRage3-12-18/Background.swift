//
//  Background.swift
//  PigRage3-12-18
//
//  Created by Emily on 3/22/18.
//  Copyright © 2018 Emily. All rights reserved.
//

import UIKit
import SpriteKit
import GameKit

class Background: SKSpriteNode {
    
    let ground = SKSpriteNode(imageNamed: "ground")
    let ground2  = SKSpriteNode(imageNamed: "ground")
    let ground3 = SKSpriteNode(imageNamed: "ground")
    
    
    
    
    convenience init() {
        self.init(imageNamed:"ground")
        //self.addChild(cloud)
        createGround()
    }
    
    func createGround(){
        //Displays the ground
        ground.position = CGPoint(x: 0, y: 75)
        self.addChild(ground)
        ground2.position = CGPoint(x: ground2.size.width - 1, y: 75)
        self.addChild(ground2)
        ground3.position = CGPoint(x: ground2.size.width + ground3.size.width - 1, y: 75)
        self.addChild(ground3)
    }
    
    func createCloud(){
        
    }
    
    func moveGround(){
        let initPosGround3 = CGPoint(x: ground2.size.width + ground3.size.width - 10, y: 75)
        //Moves the grounds left
        ground.position = CGPoint(x: ground.position.x - 20, y: ground.position.y)
        ground2.position = CGPoint(x: ground2.position.x - 20, y: ground2.position.y)
        ground3.position = CGPoint(x: ground3.position.x - 20, y: ground3.position.y)
        
        //Resets the position of the ground once it is off the screen
        if(ground.position.x < -510){
            ground.position.x = initPosGround3.x + 510
        }
        
        if(ground2.position.x < -510){
            ground2.position.x = initPosGround3.x + 510
        }
        
        if(ground3.position.x < -510){
            ground3.position.x = initPosGround3.x + 510
        }
    }
}
